#include <GL/glut.h>
#include <bits/stdc++.h>
#include <GL/gl.h>
#include <GL/freeglut.h>
#include <GL/glext.h>
using namespace std;

vector<vector<float>> vertices;      // contains vertices by their index number
vector<vector<int>> faces;           // contains vector of faces
GLfloat light_diffuse[] = {155/255.0F,132/255.0F,115/255.0F,1.0};  /* Diffuse light. */
GLfloat light_position[] = {1.0, 2.0, 1.0, 0.0};  /* Infinite light location. */
GLdouble zoom = 0.6f;
float rotatex = 0.0f;
float rotatey = 0.0f;
float xdiff = 0.0f;
float ydiff = 0.0f;
bool mouseDown = false;

vector<float> findNormal(vector<float> v1,vector<float> v2,vector<float> v3)
{
    float e1x=v2[0]-v1[0];
    float e1y=v2[1]-v1[1];
    float e1z=v2[2]-v1[2];

    float e2x=v3[0]-v1[0];
    float e2y=v3[1]-v1[1];
    float e2z=v3[2]-v1[2];

    float normx=e1y*e2z-e1z*e2y;
    float normy=e1z*e2x-e1x*e2z;
    float normz=e1x*e2y-e1y*e2x;

    float norm=normx*normx+normy*normy+normz*normz;
    norm=sqrt(norm);

    normx/=norm;
    normy/=norm;
    normz/=norm;

    return {normx,normy,normz};
}
 
void MouseFunc(int button, int state, int x, int y){

    GLdouble min_z = -100.0;
    GLdouble max_z = 100.0;

    if (button == 4 && zoom < max_z) {
        zoom -= 0.05;
        if(zoom<0.1)
            zoom=0.1;
    }
    else if (button == 3 && zoom > min_z) {
        zoom += 0.05;
    }
    
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
    {
        mouseDown = true;
        xdiff = x - rotatey;
        ydiff = -y + rotatex;
    }
    else
        mouseDown = false;
    glutPostRedisplay();
}

void mouseMotion(int x, int y)
{
    if (mouseDown)
    {
        rotatey = x - xdiff;
        rotatex = y + ydiff;
        glutPostRedisplay();
    }
}

void initGL()
{
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
    glEnable(GL_LIGHT0);
    glEnable(GL_LIGHTING);
    glClearColor(124/255.0F,252/255.0F,0.0,1.0);
    glClearDepth(1.0f);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glShadeModel(GL_SMOOTH);
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); 
    glMatrixMode(GL_MODELVIEW);     

    glLoadIdentity();                
    glScalef(zoom, zoom, 1); 
    glTranslatef(0.05f, -0.2f, -0.5f); 
    glRotatef(rotatex, 1.0f, 0.0f, 0.0f);
    glRotatef(rotatey, 0.0f, 1.0f, 0.0f);

    for(int i=0;i<faces.size();i++)
    {
        glBegin(GL_TRIANGLES);
            vector<float> vert1=vertices[faces[i][0]];
            vector<float> vert2=vertices[faces[i][1]];
            vector<float> vert3=vertices[faces[i][2]];
            vector<float> norm=findNormal(vert1,vert2,vert3);
            glNormal3f(norm[0],norm[1],norm[2]);
            glColor3f(1,0,0);
            glVertex3f(vert1[0],vert1[1],vert1[2]);
            glColor3f(0,1,0);     
            glVertex3f(vert2[0],vert2[1],vert2[2]);
            glColor3f(0,0,1);
            glVertex3f(vert3[0],vert3[1],vert3[2]);
        glEnd();
    }
    glutSwapBuffers();
}

void reshape(GLsizei width, GLsizei height)
{
    if (height == 0) height = 1;                        // To prevent divide by 0
    GLfloat aspect = (GLfloat)width / (GLfloat)height;
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);                        // To operate on the Projection matrix
    glLoadIdentity();                                   // Reset
    gluPerspective(45.0f, aspect, 0.1f, 100.0f);
}

void readObjFile(int argc, char** argv)
{
    vertices.push_back({});                             // vertices are not zero indexed
    ifstream infile(argv[argc-1]);
    string line;
    while(getline(infile, line))
    {
        istringstream iss(line);
        char ch;
        float a,b,c;
        if(!(iss>>ch>>a>>b>>c))
            break;
        if(ch=='v')
            vertices.push_back({a,b,c});
        else
            faces.push_back({(int)a,(int)b,(int)c});
    }
}
 
int main(int argc, char** argv) {
    readObjFile(argc,argv);
    glutInit(&argc, argv);            
    glutInitDisplayMode(GLUT_DOUBLE);
    glutInitWindowSize(1000,900);
    glutInitWindowPosition(0,0);
    glutCreateWindow("Bunny");
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    initGL();
    glutMouseFunc(MouseFunc);
    glutMotionFunc(mouseMotion);
    glutMainLoop();
    return 0;
}