Generating image on Linux OS

1. g++ bunny.cpp -lGL -lGLU -lglut
2. ./a.out bunny.obj

- by default image will be shown in a 900x900 dimension. On doing full screen(1920x1080), it will be resized automatically.