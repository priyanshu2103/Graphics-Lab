#include <bits/stdc++.h>
#include "GL/glut.h"
using namespace std;
typedef unsigned char uc;

// Window size
GLuint width = 1000, height = 600;
GLdouble width_step = 2.0f / width;
GLdouble height_step = 2.0f / height;

const int MAX_RAY_DEPTH = 10;

// class for 3-dim vector
class Vector_3d
{
public:
    double x, y, z;
    Vector_3d()
    {
      x = double(0.0);
      y = double(0.0);
      z = double(0.0);
    }
    Vector_3d(double t)
    {
      x = t;
      y = t;
      z = t;
    }
    Vector_3d(double x1, double y1, double z1)
    {
      x = x1;
      y = y1;
      z = z1;
    }
    // Vector normalization.
    Vector_3d& normalize()
    {
        double norm = x * x + y * y + z * z;
        if (norm > 1)
        {
            double invNorm = 1 / sqrt(norm);
            x *= invNorm, y *= invNorm, z *= invNorm;
        }
        return *this;
    }

    // Vector operators (using operator overloading)
    Vector_3d operator * (const double &f) const { return Vector_3d(x * f, y * f, z * f); }
    Vector_3d operator * (const Vector_3d &v) const { return Vector_3d(x * v.x, y * v.y, z * v.z); }
    Vector_3d& operator *= (const Vector_3d &v) { x *= v.x, y *= v.y, z *= v.z; return *this; }
    double dot(const Vector_3d &v) const { return x * v.x + y * v.y + z * v.z; }
    Vector_3d operator - () const { return Vector_3d(-x, -y, -z); }
    Vector_3d operator + (const Vector_3d &v) const { return Vector_3d(x + v.x, y + v.y, z + v.z); }
    Vector_3d operator - (const Vector_3d &v) const { return Vector_3d(x - v.x, y - v.y, z - v.z); }
    Vector_3d& operator += (const Vector_3d &v) { x += v.x, y += v.y, z += v.z; return *this; }

};

class Sphere
{
public:
    Vector_3d center;                       // position of the sphere
    double radius;                          // sphere radius                        
    double radius_squared;                  // sphere radius^2
    Vector_3d surfaceColor;                 // surface color
    Vector_3d emissionColor;                // emission
    double transparency;                    // surface transparency
    double reflection;                      // reflectivity
    bool isTextured;                        // Whether the sphere has textures or not

    Sphere(const Vector_3d &c, const double &r, const Vector_3d &sc, bool hastexture, const double &refl = 0, const double &transp = 0, const Vector_3d &ec = 0)
    {
        center = c;
        radius = r;
        surfaceColor = sc;
        isTextured = hastexture;
        reflection = refl;
        transparency = transp;
        emissionColor = ec;
        radius_squared = r * r;
    }

    // Check if ray originating from origin and in direction dir intersects sphere or not
    bool is_intersecting(const Vector_3d &origin, const Vector_3d &dir, double *temp0 = NULL, double *temp1 = NULL) const
    {
        Vector_3d l = center - origin;
        double ray = l.dot(dir);
        if (ray < 0) return false;            // If ray doesn't hit sphere, return false
        double d2 = l.dot(l) - (ray * ray);
        if (d2 > radius_squared) return false;     // If distance from center is greater than radius of sphere, it means that the ray is missing the sphere, return false
        double dist = sqrt(radius_squared - d2);
        if (temp0 != NULL && temp1 != NULL)
        {
            *temp0 = ray - dist;    // Distance from origin to first point of contact
            *temp1 = ray + dist;    // Distance from origin to last point of contact, if ray is interpolated
        }
        return true;
    }
};

vector<Sphere *> spheres;

// function for linear combination of 2 double variables.
double combination(const double &a, const double &b, const double &alpha)
{
  return a * (1.0 - alpha) + b * alpha;
}

// function for linear combination of 2 vectors.
inline Vector_3d combiVectors(const Vector_3d &a, const Vector_3d& b, const float &alpha)
{
  return a * (1 - alpha) + b * alpha;
}

/* Main function to trace a ray. If the ray intersects any sphere, 
   that pixel is colored with the color of the sphere, else with background color */
Vector_3d ray_tracing(const Vector_3d &ray_original, const Vector_3d &rayDirection, const vector<Sphere *> &spheres, const int &depth)
{
    double t_near = INFINITY;
    const Sphere *sphere = NULL;
    for (unsigned i = 0; i < spheres.size(); ++i)
    {
        double temp0 = INFINITY;
        double temp1 = INFINITY;
        if (spheres[i]->is_intersecting(ray_original, rayDirection, &temp0, &temp1))
        {
            if (temp0 < 0)
                temp0 = temp1;
            if (temp0 < t_near)
            {
                t_near = temp0;
                sphere = spheres[i];
            }
        }
    }
    // gray background color.
    if (!sphere)
        return Vector_3d(0.5);
    // initialising the color of the ray or the surface of the object intersected by the ray
    Vector_3d surfaceColor = 0;
    // intersection point
    Vector_3d hitPoint = ray_original + (rayDirection * t_near);
    // normal at the intersection point.
    Vector_3d hitNormal = hitPoint - sphere->center;

    if (rayDirection.dot(hitNormal) > 0)
        hitNormal = -hitNormal;
    // normalize normal direction
    hitNormal.normalize();

    double texture_x = (1 + atan2(hitNormal.z, hitNormal.x) / M_PI) * 0.5;
    double texture_y = acosf(hitNormal.y) / M_PI;

    double scale = 4.0;
    double pattern = (fmodf(texture_x * scale, 1) > 0.5) ^ (fmodf(texture_y * scale, 1) > 0.5);
    Vector_3d hitColor = combiVectors(sphere->surfaceColor, sphere->surfaceColor * 0.8, pattern)*(double)max((double)0.0, hitNormal.dot(-rayDirection)) ;
    if(!sphere->isTextured)
        hitColor = sphere->surfaceColor;

    double bias = 1e-5;
    // check if transparency or reflection
    if ((sphere->transparency > 0 || sphere->reflection > 0) && depth < MAX_RAY_DEPTH)
    {
        double idot_n = rayDirection.dot(hitNormal);
        double facingRatio = max(double(0), -idot_n);
        double fresnel_effect = combination(pow(1 - facingRatio, 3), 1, 0.1);
        Vector_3d reflDir = rayDirection - hitNormal * 2 * rayDirection.dot(hitNormal);
        Vector_3d reflection = ray_tracing(hitPoint + (hitNormal * bias), reflDir, spheres, depth + 1);
        Vector_3d refraction = 0;
        if (sphere->transparency)
        {
            double ior = 1.2, eta = 1 / ior;
            double k = 1 - eta * eta * (1 - idot_n * idot_n);
            Vector_3d refrdir = rayDirection * eta - hitNormal * (eta *  idot_n + sqrt(k));
            refraction = ray_tracing(hitPoint - hitNormal * bias, refrdir, spheres, depth + 1);
        }
        surfaceColor = (reflection * fresnel_effect + refraction * (1 - fresnel_effect) * sphere->transparency) * sphere->surfaceColor;
    }
    else
    {
        // If Plastic sphere then no need to trace the ray any further
        double shadow = 1.0;
        for (unsigned i = 0; i < spheres.size(); ++i) {
            if (spheres[i]->emissionColor.x > 0) {
                Vector_3d transmission = 1.0;
                Vector_3d lightDir = spheres[i]->center - hitPoint;
                lightDir.normalize();
                double lightAng = (acos(rayDirection.dot(lightDir)) / (sqrt(rayDirection.dot(rayDirection)) * sqrt(lightDir.dot(lightDir))));
                for (unsigned j = 0; j < spheres.size(); ++j)
                 {
                    if (i != j)
                    {
                        double temp0;
                        double temp1;
                        if (spheres[j]->is_intersecting(hitPoint + (hitNormal * bias), lightDir, &temp0, &temp1))
                        {
                            shadow = max(0.0, shadow - (1.0 - spheres[j]->transparency));
                            transmission = transmission * spheres[j]->surfaceColor * shadow;
                        }
                    }
                }
                surfaceColor += hitColor * transmission * max(double(0), hitNormal.dot(lightDir)) * spheres[i]->emissionColor;
            }
        }
    }
    return surfaceColor + sphere->emissionColor;
}

Vector_3d *image = new Vector_3d[width * height];
static Vector_3d camera_position = Vector_3d(0);

// rendering function which is called to render spheres which are present in vector<Sphere* > spheres
void render(const vector<Sphere *> &spheres)
{
    Vector_3d *pixel_values = image;
    double invWidhth = 1 / double(width);
    double invHeight = 1 / double(height);
    double fov = 30;
    double aspect_ratio = double(width) / double(height);
    double angle = tan(M_PI * 0.5 * fov / double(180));
    for (GLuint y = 0; y < height; ++y)
    {
        for (GLuint x = 0; x < width; ++x, ++pixel_values)
        {
            double xx = (2 * ((x + 0.5) * invWidhth) - 1) * angle * aspect_ratio;
            double yy = (1 - 2 * ((y + 0.5) * invHeight)) * angle;
            Vector_3d rayDirection(xx, yy, -1);
            rayDirection.normalize();
            *pixel_values = ray_tracing(camera_position, rayDirection, spheres, 0);
        }
    }
}

GLuint texture = 0;         // initialization
void display(void)
{
    int i;
    float x, y;
    render(spheres);

    vector<uc> buffer;
    buffer.reserve(width * height * 3);
    for(size_t y = 0; y < height; ++y)
    {
        for(size_t x = 0; x < width; ++x)
        {
            size_t i = (height-y) * width + (width-x);
            buffer.push_back((uc)(min(double(1), image[i].x) * 255.0));
            buffer.push_back((uc)(min(double(1), image[i].y) * 255.0));
            buffer.push_back((uc)(min(double(1), image[i].z) * 255.0));
        }
    }

    glClearColor(0.0, 0.0, 0.0, 0.0);
    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, width, height, GL_RGB, GL_UNSIGNED_BYTE, &buffer[0]);

    glBegin(GL_QUADS);
    glTexCoord2i(0, 0);
    glVertex2i(-1, -1);
    glTexCoord2i(1, 0);
    glVertex2i( 1, -1);
    glTexCoord2i(1, 1);
    glVertex2i( 1,  1);
    glTexCoord2i(0, 1);
    glVertex2i(-1,  1);
    glEnd();
    glutSwapBuffers();
}

/* function is called to set the textures of spheres in the scene */
void drawTextures()
{
    // Texture for the other spheres in the scene
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, NULL);
}

int main(int argc, char **argv)
{
    // sphere initialized using position, radius, surface color, textured, reflectivity, transparency, emission color
    spheres.push_back(new Sphere(Vector_3d(-1, 0, -13), 1, Vector_3d(1.0, 1.0, 0.0), false, 0, 0));        // Plastic sphere  --> Yellow
    spheres.push_back(new Sphere(Vector_3d(3, 0, -15), 3, Vector_3d(0.0, 1.0, 0.0), false, 1.0, 0.0));     // Glossy sphere --> Green
    spheres.push_back(new Sphere(Vector_3d(-1.5, 0, -6), 0.5, Vector_3d(1.0, 0.0, 0.0),true, 0.00, 0.0));  // Textured sphere--> Red

    // light source
    spheres.push_back(new Sphere(Vector_3d(10, 0, 10), 3, Vector_3d(0), false, 0, 0, Vector_3d(3)));

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(width, height);
    glutInitWindowPosition(150,150);
    glutCreateWindow("Plastic, Textured and Glossy Spheres");
    glutDisplayFunc(display);
    drawTextures();
    glutMainLoop();
    return 0;
}
