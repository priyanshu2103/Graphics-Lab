1. To run the code, open terminal and compile with "g++ 170101049_Assignment3.cpp -lGL -lGLU -lglut -o lab3" and run with "./lab3"

2. The rendered image contains 3 spheres:-
	a. Glossy :- Green Color
	b. Plastic :- Yellow Color
	c. Textured :- Red Color

	Due to the nature of glossy sphere, you can see 3 reflections on it's surface
	(i) light source
	(ii) plastic sphere
	(iii) textured sphere - not clearly visible(a small portion between 2 reflections)